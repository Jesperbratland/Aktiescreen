"""Aktiescreen – portföljdashboard, aktieanalys och screener.

Starta med:  streamlit run app.py
"""
import streamlit as st

st.set_page_config(page_title="Aktiescreen", page_icon="📈", layout="wide",
                   initial_sidebar_state="expanded")

from core.ui import inject_css  # noqa: E402
from views import overview, screener_page, stock_analysis, tips, transactions  # noqa: E402

inject_css()

pages = {
    "oversikt": st.Page(overview.render, title="Översikt", icon="📊", url_path="oversikt", default=True),
    "transaktioner": st.Page(transactions.render, title="Transaktioner", icon="🧾", url_path="transaktioner"),
    "analys": st.Page(stock_analysis.render, title="Aktieanalys", icon="🔬", url_path="analys"),
    "screener": st.Page(screener_page.render, title="Screener", icon="🧭", url_path="screener"),
    "tips": st.Page(tips.render, title="Tips & insikter", icon="💡", url_path="tips"),
}
st.session_state["_pages"] = pages

nav = st.navigation({
    "Portfölj": [pages["oversikt"], pages["transaktioner"]],
    "Analys": [pages["analys"], pages["screener"], pages["tips"]],
})

with st.sidebar:
    st.markdown("### 📈 Aktiescreen")
    if st.button("🔄 Uppdatera kurser", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.caption("Kurser via Yahoo Finance (kan vara ~15 min fördröjda). Data lagras lokalt i data/portfolio.db.")

nav.run()
