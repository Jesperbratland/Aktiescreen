# CLAUDE.md – Aktiescreen

Streamlit-app (Python) för portföljuppföljning, aktieanalys och screening. Svenska i UI, engelska variabelnamn.

## Köra
- `pip install -r requirements.txt`
- `streamlit run app.py`

## Struktur
- `app.py` – sidkonfiguration, navigation (`st.navigation`), sidomeny.
- `core/` – logik utan UI (förutom `st.cache_data`):
  - `db.py` – SQLite (`data/portfolio.db`), tabellen `transactions`. Typer: KÖP/SÄLJ/UTDELNING. `fee` alltid i SEK, `fx_rate` = SEK per 1 enhet valuta.
  - `market.py` – all yfinance-access, cachad. Lägg nya datakällor här.
  - `portfolio.py` – GAV (genomsnittsmetoden), realiserat resultat, `portfolio_history` (värde, nettoinsatt, TWR).
  - `analysis.py` – indikatorer (SMA, EMA, RSI Wilder, MACD, Bollinger), riskmått, `technical_signals`.
  - `screener.py` – urval (`UNIVERSES`), teknisk/fundamental snapshot, percentilbaserad poäng.
  - `ui.py` – svensk talformatering (`fmt_sek`, `fmt_pct` tar andelar, 0.05 = 5 %), CSS, signalkort.
- `views/` – en fil per sida med en `render()`-funktion.

## Konventioner
- Procent lagras som andelar i data. Multiplicera med 100 först vid visning i `st.dataframe` med `format="%.1f %%"`.
- Nya sidor: skapa `views/x.py` med `render()`, registrera i `pages` i `app.py` med unik `url_path`.
- Validera alltid transaktioner med `portfolio.validate()` innan du skriver till databasen.
- Kör `python -m py_compile app.py core/*.py views/*.py` efter ändringar.

## Idéer för vidareutveckling
- Import av Avanza/Nordnet-CSV (mappa ISIN → Yahoo-ticker).
- Bevakningslista med kurslarm.
- Utdelningskalender och prognos för kommande utdelningar (`yf.Ticker(t).dividends`, `.calendar`).
- Extern databas (Supabase/Postgres via `st.connection`) för drift på Streamlit Cloud.
- Inloggning (`st.login` med OIDC) om appen ska ligga publikt.
- Skatteunderlag: K4-sammanställning per år från realiserade affärer.
